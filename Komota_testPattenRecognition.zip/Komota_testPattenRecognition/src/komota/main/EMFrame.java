package komota.main;

import java.awt.Color;
import java.util.ArrayList;

import komota.supers.MyFrame;

public class EMFrame extends MyFrame{

	public ArrayList<double[]> dataset;

	//クラスタ数
	final int K = 4;

	double[] pi = new double[K];
	double[][] myu = new double[K][2];
	double[][][] sigma = new double[K][2][2];

	double[][] gamma;

	//画面端の位置(定数)
	final int FRAMESIDE = 50;
	final int NODESIZE = 10;

	//EM
	final int E = 0;
	final int M = 1;


	//描画時の平行移動量と倍率
	int MOVE_X;
	int MOVE_Y;
	int SCALE;

	//EM切り替え
	int emswitch = E;

	//コンストラクタ
	public EMFrame(ArrayList<double[]> dataset) {
		super("VisualEM");
		this.dataset = dataset;
		this.MOVE_X = 40;
		this.MOVE_Y = 40;
		this.SCALE = 2000;
		this.playflag = true;

		gamma = new double[dataset.size()][K];

		for(int i=0;i<K;i++){
			pi[i] = Math.random();
			myu[i][0] = Math.random();
			myu[i][1] = Math.random();
			sigma[i][0][0] = Math.random();
			sigma[i][0][1] = Math.random();
			sigma[i][1][0] = Math.random();
			sigma[i][1][1] = Math.random();
		}
		// TODO 自動生成されたコンストラクター・スタブ
	}

	@Override
	public void run() {
		// TODO 自動生成されたメソッド・スタブ

		//パラメータ更新用のフラグ
		boolean MOVE_X_flag = false;
		boolean MOVE_Y_flag = false;
		boolean SCALE_flag = false;

		for(int i = 0;i < this.dataset.size(); i++){
			Color color = null;
			switch ((int)this.dataset.get(i)[2]) {
			case 0:
				color = Color.red;
				break;
			case 1:
				color = Color.blue;
				break;
			case 2:
				color = Color.green;
				break;
			case 3:
				color = Color.orange;
				break;
			case 4:
				color = Color.cyan;
				break;
			case 5:
				color = Color.pink;
				break;
			default:
				color = Color.white;
			}

			//現在のパラメータでは画面外にはみ出してしまうデータがある場合、更新フラグを立てる
			if((this.dataset.get(i)[0])*SCALE+MOVE_X < FRAMESIDE){
				MOVE_X_flag = true;
			}
			if((this.dataset.get(i)[1])*SCALE+MOVE_Y < FRAMESIDE){
				MOVE_Y_flag = true;
			}
			if((this.dataset.get(i)[0])*SCALE+MOVE_X > this.getWidth() - FRAMESIDE || (this.dataset.get(i)[1])*SCALE+MOVE_Y > this.getHeight() - FRAMESIDE){
				SCALE_flag = true;
			}



			drawDot((this.dataset.get(i)[0])*SCALE+MOVE_X,
					(this.dataset.get(i)[1])*SCALE+MOVE_Y,
					NODESIZE,
					color);
		}
		//描画位置を調節するパラメータを学習する
		if(MOVE_X_flag == true){
			MOVE_X += FRAMESIDE;
		}
		if(MOVE_Y_flag == true){
			MOVE_Y += FRAMESIDE;
		}
		if(SCALE_flag == true){
			SCALE -= FRAMESIDE / 10;
			MOVE_X -= FRAMESIDE;
			MOVE_Y -= FRAMESIDE;
		}
	}

	//キーが入力されたときに実行するメソッド。EとMをスイッチして実行するだけ
	void stepEM(){
		if(emswitch == E){
			emswitch = M;
			stepE();
		}
		else{
			emswitch = E;
			stepM();
		}
	}

	//Eステップ
	void stepE(){
		System.out.println("E");
		/*
		double temp = 0;
		NormalDistribution gauss;
		for(int i=0;i<this.dataset.size();i++){
			for(int j=0;j<K;j++){
				gauss = new NormalDistribution(myu[j],sigma[j]);
				temp += pi[j]*gauss.frequencyOf_2D(dataset.get(i));
			}
			gamma[i][j] = 1/temp;
		}
		*/
	}
	//Mステップ
	void stepM(){
		System.out.println("M");
	}



	}


