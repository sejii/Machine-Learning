package komota.main;

import komota.supers.VisualSOINN;
import soinn.SOINN;

public class VisualRRSOINN extends VisualSOINN{

	//RemoveRectangle(矩形ノイズ除去)SOINNのテスト用クラス。煩雑なので消してもいい

	int timeframe = 0;

	public VisualRRSOINN(SOINN soinn) {
		super(soinn);
		// TODO 自動生成されたコンストラクター・スタブ
	}

	@Override
	public void run(){
		super.run();
		if(timeframe++ >= 2000){
			System.out.println("[VisualRRSOINN]		RR done.");
			this.getSOINN().komota_removeChain();
			this.timeframe = 0;
		}
	}

}
