package komota.main;

import java.util.ArrayList;

public class Sin {

	int num = 10000;

	ArrayList<double[]> sins = new ArrayList<double[]>();

	//コンストラクタ

	public Sin(){
		for(int i=0;i<num;i++){
			double[] temp = new double[2];

		}
	}

}
