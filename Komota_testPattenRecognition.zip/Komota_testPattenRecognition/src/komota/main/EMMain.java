package komota.main;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import komota.supers.MyDataFilter;

public class EMMain {

	EMFrame frame;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		Gauss gauss = new Gauss();
		ArrayList<double[]> predataset = MyDataFilter.normalization(gauss.gauss);
		ArrayList<double[]> dataset = new ArrayList<double[]>();

			for(int i=0;i<predataset.size();i++){
				double[] temp = {predataset.get(i)[0],predataset.get(i)[1],-1};
				dataset.add(temp);
			}

		EMMain main = new EMMain();
		main.frame = new EMFrame(dataset);

		main.frame.addKeyListener(main.new MyKeyListener());
	}


	class MyKeyListener implements KeyListener{

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO 自動生成されたメソッド・スタブ
			EMMain.this.frame.stepEM();
		}

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO 自動生成されたメソッド・スタブ

		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO 自動生成されたメソッド・スタブ

		}

	}

}
