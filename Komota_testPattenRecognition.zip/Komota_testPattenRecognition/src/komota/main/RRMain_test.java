package komota.main;

import java.util.ArrayList;

import komota.supers.MyDataFilter;
import komota.supers.VisualSOINN;
import soinn.SOINN;


//2015/5/29
//教師ありのガウスデータを用いたSOINNの定量評価の方法の考察とRRSOINNの実験環境。

public class RRMain_test {

	//テスト用カウンター
	int countdata = 0;
	int countfeature = 0;
	int countcurrent = 0;

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		ArrayList<double[]> samplegauss = new ArrayList<double[]>();

		SupervisedGauss gauss = new SupervisedGauss();

		samplegauss = MyDataFilter.normalization(gauss.gauss);
		SOINN soinn = new SOINN(2,100,10);

		/* ************************************************************************************************************* */
		//データを与えきってからVisualSOINNを生成する
/*
		for(int i=0;i<samplegauss.size();i++){
			double[] tempdata = {samplegauss.get(i)[0],samplegauss.get(i)[1]};
			soinn.inputSignal(tempdata);
		}
		soinn.removeUnnecessaryNode();
		VisualSOINN frame = new VisualSOINN(soinn);

		//隣接ノード数の割合を出力させる
		System.out.println("[IrisMain_SOINN]		the number of Node which has 2 neighbor 	is :"+soinn.komota_CountNodeOnNumberOfNeighbor(2));
		System.out.println("[IrisMain_SOINN]		the number of Node which has 3 neighbor 	is :"+soinn.komota_CountNodeOnNumberOfNeighbor(3));
		System.out.println("[IrisMain_SOINN]		the number of Node which has 4 neighbor 	is :"+soinn.komota_CountNodeOnNumberOfNeighbor(4));
		System.out.println("[IrisMain_SOINN]		the number of Node which has 5 neighbor 	is :"+soinn.komota_CountNodeOnNumberOfNeighbor(5));
		System.out.println("[IrisMain_SOINN]		the number of Node which has 6 neighbor 	is :"+soinn.komota_CountNodeOnNumberOfNeighbor(6));
		System.out.println("[IrisMain_SOINN]		the number of Node which has 7 neighbor 	is :"+soinn.komota_CountNodeOnNumberOfNeighbor(7));

		//2つ以上並んだ隣接ノード数2のノードの数を出力する
		System.out.println("[IrisMain_SOINN]		the number of Node which has chain	 	is :"+soinn.komota_CountNode_Chain() + "of all node:"+soinn.getNodeNum(true));
*/


		/* ************************************************************************************************************* */

		/* ************************************************************************************************************* */
		//VisualSOINNを生成してからデータを与える。（順序通り）

		VisualSOINN frame = new VisualSOINN(soinn,"VisualRRSOINN",40,40,2000);

		frame.setDataset(samplegauss);
		frame.setRealtimeFlag(true);
		frame.setRandomDataFlag(true);

		/* ************************************************************************************************************* */

		while(frame != null){
			try {
				Thread.sleep(100);
				System.out.println("とおっているよん");
			} catch (InterruptedException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}
			if(frame.getRealtimeFlag() == false){
				System.out.println("わん");
				SupervisedGauss testgauss = new SupervisedGauss();
				ArrayList<double[]> testdata = testgauss.gauss;
				int i=0;
				//同一クラスタに所属するべきデータのみ抽出する
				while(i<testdata.size()){
					System.out.println("つー");
					if(testdata.get(i)[2] != 1){
						testdata.remove(i);
					}
					else{
						i++;
					}
				}
				for(int j=0;j<testdata.size();j++){
					System.out.println("[RRMain_test]		this data is the class: "+ soinn.komota_getTestdataClass(testdata.get(j)));
				}
			}
		}



	}
}
